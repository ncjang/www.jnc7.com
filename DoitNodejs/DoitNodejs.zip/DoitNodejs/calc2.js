var calc = {};

calc.add = function(a, b) {
    return a + b;
};

module.exports = calc;