//모둘 불러오기 : require
var calc = require('./calc');

console.log('모듈로 분리한 수 - calc.add : ', calc.add(20, 20));
