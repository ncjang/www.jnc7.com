//내장모듈 사용
var os = require('os')

console.log('hostname : ', os.hostname());
console.log('memory : ', os.freemem());